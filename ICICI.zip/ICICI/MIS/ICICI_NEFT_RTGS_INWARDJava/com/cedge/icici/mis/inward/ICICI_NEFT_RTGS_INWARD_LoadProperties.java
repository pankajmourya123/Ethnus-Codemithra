package com.cedge.icici.mis.inward;

import java.io.File;
import java.io.FileInputStream;
import java.util.Properties;

public class ICICI_NEFT_RTGS_INWARD_LoadProperties 
{
	public static void getProperties( String propLoc, String key,String bankName, String[] fileLoc, String[] ftpProv )
	{	
		Properties properties = new Properties();
		try {
			File propFile = new File(propLoc);
			FileInputStream fileInput = new FileInputStream(propFile);
			properties.load(fileInput);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fileLoc[0] = properties.getProperty(key);
		ftpProv[0] = properties.getProperty(bankName + "_CBS_SFTP");
		
	}

	/*
	public static void getSFTPProperties( String propLoc, String key, String[] fileLoc, String[] ftpProv , String bankName)
	{	
		Properties properties = new Properties();
		try {
			File propFile = new File(propLoc);
			FileInputStream fileInput = new FileInputStream(propFile);
			properties.load(fileInput);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		fileLoc[0] = properties.getProperty(key);
		ftpProv[0] = properties.getProperty(bankName+"_SFTP");
		
	}
    */
	public static void getMailProp( String propLoc, String[] toEmail, String[] ccEmail, String[] fromEmail, String[] smtpServer)
    {
        Properties properties = new Properties();
        try {
            File propFile = new File(propLoc);
            FileInputStream fileInput = new FileInputStream(propFile);
            properties.load(fileInput);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        toEmail[0] = properties.getProperty("MailTo");
        ccEmail[0] = properties.getProperty("MailCc");
        fromEmail[0] = properties.getProperty("MailFrom");
        smtpServer[0] = properties.getProperty("MailHost");

    }
}
